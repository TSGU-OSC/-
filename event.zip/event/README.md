# 开源社团活动

* 🚀[第一次活动：2022年末](./active1/README.md)

* 🚀[第二次活动：开源社团迎新晚会](./active2/README.md)

* 🚀[第三次活动：首次技术讲座](./active3/README.md)

* 🚀[第四次活动：PR比赛](./active4/README.md)

* 🚀[第五次活动：如何使用开源项目](./active5/README.md)

* 🚀[第六次活动：Linux入门培训](./active6/README.md)

* 🚀[第七次活动：如何有效利用服务器资源](./active7/README.md)

* 🚀[第八次活动：华为昇腾AI全国行](./active8/README.md)

* 🚀[第九次活动：开放原子校源行（北理工站）](./active9/README.md)
